from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncio
import json
from datetime import datetime
from typing import Set
import uuid

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Store active connections and messages
class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, asyncio.Queue] = {}
        self.messages: list[dict] = []
        self.max_messages = 100  # Keep last 100 messages in memory
        
    async def connect(self, client_id: str) -> asyncio.Queue:
        """Create a new queue for a client connection"""
        queue = asyncio.Queue(maxsize=100)
        self.active_connections[client_id] = queue
        return queue
    
    def disconnect(self, client_id: str):
        """Remove client connection"""
        if client_id in self.active_connections:
            del self.active_connections[client_id]
    
    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        # Store message
        self.messages.append(message)
        if len(self.messages) > self.max_messages:
            self.messages.pop(0)
        
        # Send to all connected clients
        disconnected_clients = []
        for client_id, queue in self.active_connections.items():
            try:
                # Non-blocking put with timeout
                await asyncio.wait_for(queue.put(message), timeout=0.1)
            except asyncio.TimeoutError:
                # Queue is full, client is too slow
                disconnected_clients.append(client_id)
            except Exception:
                disconnected_clients.append(client_id)
        
        # Clean up disconnected clients
        for client_id in disconnected_clients:
            self.disconnect(client_id)
    
    def get_recent_messages(self) -> list[dict]:
        """Get recent message history"""
        return self.messages.copy()

manager = ConnectionManager()

class Message(BaseModel):
    username: str
    content: str

@app.get("/")
async def get_chat_page():
    """Serve the chat HTML page"""
    with open("/home/claude/index.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.get("/api/messages")
async def get_messages():
    """Get recent message history"""
    return {"messages": manager.get_recent_messages()}

@app.post("/api/messages")
async def post_message(message: Message):
    """Post a new message"""
    msg_data = {
        "id": str(uuid.uuid4()),
        "username": message.username,
        "content": message.content,
        "timestamp": datetime.utcnow().isoformat()
    }
    
    await manager.broadcast(msg_data)
    return {"status": "ok", "message": msg_data}

@app.get("/api/stream")
async def stream_messages(request: Request):
    """SSE endpoint for streaming messages to clients"""
    client_id = str(uuid.uuid4())
    queue = await manager.connect(client_id)
    
    async def event_generator():
        try:
            # Send initial connection message
            yield f"data: {json.dumps({'type': 'connected', 'client_id': client_id})}\n\n"
            
            while True:
                # Check if client disconnected
                if await request.is_disconnected():
                    break
                
                try:
                    # Wait for new message with timeout
                    message = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield f"data: {json.dumps(message)}\n\n"
                except asyncio.TimeoutError:
                    # Send keepalive ping every 30 seconds
                    yield f": keepalive\n\n"
                    
        except asyncio.CancelledError:
            pass
        finally:
            manager.disconnect(client_id)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"  # Disable nginx buffering
        }
    )

@app.get("/api/stats")
async def get_stats():
    """Get server statistics"""
    return {
        "active_connections": len(manager.active_connections),
        "total_messages": len(manager.messages)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
