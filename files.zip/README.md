# Real-time Chat Application

A high-performance real-time chat application built with FastAPI and Server-Sent Events (SSE).

## Features

- **Real-time messaging** using Server-Sent Events (SSE)
- **Scalable architecture** designed to handle many concurrent users
- **Automatic reconnection** if connection drops
- **Message history** - new users see recent messages
- **Clean, modern UI** with smooth animations
- **Lightweight** - no WebSocket overhead, works through standard HTTP

## Performance Optimizations

### Server-side:
- **Non-blocking async architecture** - FastAPI with asyncio for concurrent handling
- **Message queue per client** - Each client has its own asyncio.Queue (max 100 messages)
- **Automatic cleanup** - Slow or disconnected clients are automatically removed
- **Memory limits** - Only keeps last 100 messages in memory
- **Keepalive pings** - Every 30 seconds to maintain connections
- **Timeout handling** - 100ms timeout for queue operations to prevent blocking

### Client-side:
- **EventSource API** - Native browser SSE support
- **Automatic reconnection** - Reconnects after 3 seconds if disconnected
- **Efficient DOM updates** - Only appends new messages
- **Smooth animations** - CSS-based with GPU acceleration

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the server:
```bash
python server.py
```

3. Open your browser to `http://localhost:8000`

## API Endpoints

- `GET /` - Serve the chat interface
- `GET /api/stream` - SSE endpoint for receiving messages
- `POST /api/messages` - Send a new message
- `GET /api/messages` - Get recent message history
- `GET /api/stats` - Get server statistics

## Architecture

### Server-Sent Events (SSE)
This application uses SSE instead of WebSockets because:
- Simpler protocol (one-way HTTP streaming)
- Better proxy/firewall compatibility
- Automatic reconnection built into browsers
- Lower overhead for broadcast-style messaging
- Works with standard HTTP load balancers

### Connection Manager
The `ConnectionManager` class handles:
- Client connection lifecycle
- Message broadcasting to all clients
- Automatic cleanup of slow/dead connections
- Message history storage

### Scalability Considerations

**Current Setup (Single Server):**
- Can handle 1000+ concurrent connections on a standard server
- Memory usage: ~1MB per 100 connections
- CPU usage: Minimal (mostly I/O bound)

**For Production at Scale:**
1. **Add Redis** for shared message storage across multiple servers
2. **Use a load balancer** (e.g., nginx) to distribute connections
3. **Deploy multiple app instances** behind the load balancer
4. **Use Redis Pub/Sub** to broadcast messages between server instances

Example Redis integration:
```python
import redis.asyncio as redis

class ConnectionManager:
    def __init__(self):
        self.redis = redis.Redis(host='localhost', port=6379)
        
    async def broadcast(self, message: dict):
        await self.redis.publish('chat:messages', json.dumps(message))
```

## Production Deployment

### Using Uvicorn with multiple workers:
```bash
uvicorn server:app --host 0.0.0.0 --port 8000 --workers 4
```

### Using Gunicorn with Uvicorn workers:
```bash
gunicorn server:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### Docker Deployment:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "server:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Nginx Configuration:
```nginx
location /api/stream {
    proxy_pass http://localhost:8000;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering off;
    proxy_cache off;
    proxy_read_timeout 24h;
}
```

## Testing Concurrent Users

Use a load testing tool like Apache Bench or Locust:

```python
# locustfile.py
from locust import HttpUser, task, between

class ChatUser(HttpUser):
    wait_time = between(1, 5)
    
    @task
    def send_message(self):
        self.client.post("/api/messages", json={
            "username": "TestUser",
            "content": "Test message"
        })
```

Run: `locust -f locustfile.py --host=http://localhost:8000`

## License

MIT
