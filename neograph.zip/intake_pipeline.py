"""
Extract entities & relationships from a directory of markdown files
using neo4j-graphrag-python (verified against v1.18.0) — NO Neo4j instance required.

Pipeline: read .md files -> chunk -> LLM extraction (schema-guided, open) -> local JSON

Install:
    pip install "neo4j-graphrag[bedrock]"

Run (uses standard AWS credential chain: env vars, ~/.aws, instance role, etc.):
    python extract_kg_to_json.py ./docs ./output.json
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from neo4j_graphrag.llm import BedrockLLM
from neo4j_graphrag.experimental.components.schema import GraphSchema
from neo4j_graphrag.experimental.components.text_splitters.fixed_size_splitter import (
    FixedSizeSplitter,
)
from neo4j_graphrag.experimental.components.entity_relation_extractor import (
    LLMEntityRelationExtractor,
    OnError,
)
from neo4j_graphrag.llm import AnthropicLLM

load_dotenv()


# ---------------------------------------------------------------------------
# 1. Schema: the node/relationship types you want the LLM to look for.
#    additional_node_types / additional_relationship_types = True means the
#    LLM may ALSO emit types outside this list (schema-guided, not constrained).
# ---------------------------------------------------------------------------
SCHEMA = GraphSchema.model_validate(
    {
        "node_types": [
            {"label": "Doctor", "properties": [{"name": "name", "type": "STRING"},
                                               {"name": "specialty", "type": "STRING"}]},
            {"label": "Electrician", "properties": [{"name": "name", "type": "STRING"}]},
            {"label": "Accountant", "properties": [{"name": "name", "type": "STRING"}]},
            {"label": "Firm", "properties": [{"name": "name", "type": "STRING"},
                                             {"name": "industry", "type": "STRING"}]},
        ],
        "relationship_types": ["WORKS_FOR", "PARTNERS_WITH", "SERVES"],
        "additional_node_types": True,          # allow out-of-schema entity types
        "additional_relationship_types": True,  # allow out-of-schema relationship types
    }
)

# ---------------------------------------------------------------------------
# 2. Model: BedrockLLM calls the boto3 Converse API and passes model_name
#    through as the modelId. For an APPLICATION inference profile, use the
#    full profile ARN (the bare profile ID is not accepted by Converse).
#    model_params uses Converse inferenceConfig naming (camelCase).
# ---------------------------------------------------------------------------
# INFERENCE_PROFILE_ARN = (
#     "arn:aws:bedrock:us-east-1:123456789012:"
#     "application-inference-profile/abc123xyz"  # <-- your profile ARN here
# )
#
# llm = BedrockLLM(
#     model_name=INFERENCE_PROFILE_ARN,
#     model_params={"maxTokens": 4000, "temperature": 0.0},
#     region_name="us-east-1",  # must match the profile's region
# )

llm = AnthropicLLM(
    model_name="claude-haiku-4-5",
    model_params={"max_tokens": 5000, "temperature": 0},
    api_key=os.environ.get("ANTHROPIC_API_KEY"),
)

splitter = FixedSizeSplitter(chunk_size=1500, chunk_overlap=150)

extractor = LLMEntityRelationExtractor(
    llm=llm,
    create_lexical_graph=False,   # skip Chunk/Document nodes; entities only
    on_error=OnError.IGNORE,      # skip chunks with malformed LLM output
    max_concurrency=5,
)

async def extract_file(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    chunks = await splitter.run(text=text)
    graph = await extractor.run(chunks=chunks)#, schema=SCHEMA)  # returns Neo4jGraph
    return {
        "source_file": str(path),
        "nodes": [n.model_dump() for n in graph.nodes],
        "relationships": [r.model_dump() for r in graph.relationships],
    }


async def main(input_dir: str, output_file: str) -> None:
    md_files = sorted(Path(input_dir).glob("*.md"))
    if not md_files:
        sys.exit(f"No .md files found in {input_dir}")

    results = []
    for f in md_files:
        print(f"Extracting: {f.name}")
        results.append(await extract_file(f))

    total_nodes = sum(len(r["nodes"]) for r in results)
    total_rels = sum(len(r["relationships"]) for r in results)

    Path(output_file).write_text(
        json.dumps({"documents": results,
                    "totals": {"nodes": total_nodes, "relationships": total_rels}},
                   indent=2, default=str),
        encoding="utf-8",
    )
    print(f"Done: {total_nodes} nodes, {total_rels} relationships -> {output_file}")


if __name__ == "__main__":
    in_dir = sys.argv[1] if len(sys.argv) > 1 else "./docs"
    out_file = sys.argv[2] if len(sys.argv) > 2 else "./extraction_output.json"
    asyncio.run(main(in_dir, out_file))