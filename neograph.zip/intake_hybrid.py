"""
Hybrid entity/relationship extraction from markdown files using Claude on
AWS Bedrock (application inference profile), outputting local JSON.

Unified flow:
  - Header-aware sectioning with a large target size. Small docs naturally
    come out as ONE section -> whole-document extraction + optional gleaning
    pass. Multi-section docs -> per-section extraction with an entity
    registry carried forward -> one consolidation pass that merges duplicates
    and normalizes relationship type names.

Structured output is enforced via Converse tool use (toolChoice forces the
model to return JSON matching the tool schema - no parse-and-pray).

Install:
    pip install boto3

Run (standard AWS credential chain):
    python hybrid_extract.py ./docs ./output.json
"""

from __future__ import annotations

import json
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class Config:
    # Full ARN required for application inference profiles (bare ID won't work)
    model_id: str = (
        "arn:aws:bedrock:us-east-1:123456789012:"
        "application-inference-profile/abc123xyz"
    )
    region: str = "us-east-1"           # must match the profile's region
    # One knob: section size. Docs at or under this become a single section
    # (whole-document extraction); larger docs get split at header boundaries.
    section_target_tokens: int = 30_000
    max_output_tokens: int = 8_000
    gleaning: bool = True               # "what did you miss" pass (single-section docs)
    max_retries: int = 5

    # Entity types to look for. Open schema: the prompt explicitly allows
    # types outside this list. Relationship types are discovered freely.
    node_types: list = field(default_factory=lambda: [
        {"label": "Doctor",      "properties": ["name", "specialty"]},
        {"label": "Electrician", "properties": ["name"]},
        {"label": "Accountant",  "properties": ["name"]},
        {"label": "Firm",        "properties": ["name", "industry"]},
    ])


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

def system_prompt(cfg: Config) -> str:
    return f"""You are an expert at building knowledge graphs from documents.

Extract entities (nodes) and the relationships between them from the text.

PRIORITY ENTITY TYPES (extract these whenever present):
{json.dumps(cfg.node_types, indent=2)}

RULES:
- You MAY also create entity types NOT in the list above if the text clearly
  contains other significant entities. Do not force entities into wrong types.
- For each entity, extract the listed properties when available, and ANY other
  clearly stated properties as additional keys (open schema).
- Discover relationship types naturally from the text. Use UPPER_SNAKE_CASE
  names (e.g. WORKS_FOR, PARTNERS_WITH). Prefer reusing a relationship type
  you have already used over inventing a near-synonym.
- Every entity needs a unique string "id" within your response. Relationships
  reference those ids via start_node_id / end_node_id.
- Only extract what the text states or directly implies. Never invent facts.
- Record extraction results by calling the record_extraction tool."""


REGISTRY_ADDENDUM = """
KNOWN ENTITIES (already extracted from earlier sections of this same document):
{registry}

If any of these entities appear in this section, reuse their EXACT name and
label so they can be linked. Still assign them a new id in your response and
re-list them in nodes if they participate in new relationships or have new
properties.
"""

CONSOLIDATION_PROMPT = """Below are entities and relationships extracted
section-by-section from ONE document. Some entities are duplicates (same
real-world thing, possibly with name variants or abbreviations) and some
relationship types are near-synonyms.

Produce the consolidated graph:
1. Merge duplicate entities. Keep the most complete/formal name; union their
   properties (keep both values on conflict, as "value1 | value2").
2. Normalize relationship types: map near-synonyms (WORKS_FOR / EMPLOYED_BY /
   WORKS_AT) to a single canonical type.
3. Rewrite relationships to reference the merged entity ids; drop exact
   duplicate relationships.
4. Do NOT drop non-duplicate information. Do NOT add anything new.

Record the result by calling the record_extraction tool.

EXTRACTED DATA:
{data}"""

GLEANING_PROMPT = """You previously extracted the following from this document:

{previous}

Re-read the document text below. Record ONLY entities and relationships that
are present in the text but MISSING from the extraction above (empty lists if
nothing was missed). Use new unique ids; reuse exact names for entities that
already exist.

DOCUMENT:
{text}"""


# ---------------------------------------------------------------------------
# Bedrock call with forced tool use (guaranteed-structure JSON)
# ---------------------------------------------------------------------------

EXTRACTION_TOOL = {
    "toolSpec": {
        "name": "record_extraction",
        "description": "Record extracted entities and relationships.",
        "inputSchema": {"json": {
            "type": "object",
            "properties": {
                "nodes": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "label": {"type": "string"},
                            "properties": {"type": "object"},
                        },
                        "required": ["id", "label", "properties"],
                    },
                },
                "relationships": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "start_node_id": {"type": "string"},
                            "end_node_id": {"type": "string"},
                            "type": {"type": "string"},
                            "properties": {"type": "object"},
                        },
                        "required": ["start_node_id", "end_node_id", "type"],
                    },
                },
            },
            "required": ["nodes", "relationships"],
        }},
    }
}

RETRYABLE = {"ThrottlingException", "ModelTimeoutException",
             "ServiceUnavailableException", "InternalServerException"}


def call_claude(client, cfg: Config, system: str, user_text: str) -> dict:
    """One Converse call; returns the tool input dict {nodes, relationships}."""
    for attempt in range(cfg.max_retries):
        try:
            resp = client.converse(
                modelId=cfg.model_id,
                system=[{"text": system}],
                messages=[{"role": "user", "content": [{"text": user_text}]}],
                inferenceConfig={"maxTokens": cfg.max_output_tokens,
                                 "temperature": 0.0},
                toolConfig={"tools": [EXTRACTION_TOOL],
                            "toolChoice": {"tool": {"name": "record_extraction"}}},
            )
            for block in resp["output"]["message"]["content"]:
                if "toolUse" in block:
                    out = block["toolUse"]["input"]
                    return {"nodes": out.get("nodes", []),
                            "relationships": out.get("relationships", [])}
            raise RuntimeError("No toolUse block in model response")
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code in RETRYABLE and attempt < cfg.max_retries - 1:
                wait = 2 ** attempt
                print(f"  {code}, retrying in {wait}s...")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError("Retries exhausted")


# ---------------------------------------------------------------------------
# Token estimation & markdown sectioning
# ---------------------------------------------------------------------------

def estimate_tokens(text: str) -> int:
    return len(text) // 4  # rough; fine for routing


def split_markdown_sections(text: str, target_tokens: int) -> list[str]:
    """Split on markdown headers, then greedily pack pieces up to target size.
    Oversized headerless pieces fall back to paragraph splitting."""
    pieces = re.split(r"(?m)(?=^#{1,3} )", text)
    pieces = [p for p in pieces if p.strip()]

    expanded: list[str] = []
    for p in pieces:
        if estimate_tokens(p) <= target_tokens:
            expanded.append(p)
        else:  # single huge section: split by paragraphs
            buf = ""
            for para in p.split("\n\n"):
                if estimate_tokens(buf) + estimate_tokens(para) > target_tokens and buf:
                    expanded.append(buf)
                    buf = para
                else:
                    buf = f"{buf}\n\n{para}" if buf else para
            if buf.strip():
                expanded.append(buf)

    sections: list[str] = []
    buf = ""
    for p in expanded:  # greedy packing of small pieces
        if estimate_tokens(buf) + estimate_tokens(p) > target_tokens and buf:
            sections.append(buf)
            buf = p
        else:
            buf = f"{buf}\n{p}" if buf else p
    if buf.strip():
        sections.append(buf)
    return sections


# ---------------------------------------------------------------------------
# Extraction strategies
# ---------------------------------------------------------------------------

def merge_graphs(a: dict, b: dict) -> dict:
    return {"nodes": a["nodes"] + b["nodes"],
            "relationships": a["relationships"] + b["relationships"]}


def extract(client, cfg: Config, text: str) -> tuple[str, dict]:
    """Unified extraction. Returns (strategy, graph)."""
    sections = split_markdown_sections(text, cfg.section_target_tokens)

    # --- single section: whole-document extraction (+ optional gleaning) ---
    if len(sections) == 1:
        graph = call_claude(client, cfg, system_prompt(cfg), sections[0])
        if cfg.gleaning:
            missed = call_claude(
                client, cfg, system_prompt(cfg),
                GLEANING_PROMPT.format(previous=json.dumps(graph),
                                       text=sections[0]),
            )
            if missed["nodes"] or missed["relationships"]:
                print(f"  gleaning found {len(missed['nodes'])} more nodes, "
                      f"{len(missed['relationships'])} more relationships")
                graph = merge_graphs(graph, missed)
        return "whole_document", graph

    # --- multiple sections: registry carry-forward + consolidation ---
    print(f"  {len(sections)} sections")
    registry: dict[str, str] = {}   # entity name -> label (carry-forward)
    combined = {"nodes": [], "relationships": []}

    for i, section in enumerate(sections):
        system = system_prompt(cfg)
        if registry:
            reg_txt = "\n".join(f"- {name} ({label})"
                                for name, label in registry.items())
            system += REGISTRY_ADDENDUM.format(registry=reg_txt)

        graph = call_claude(client, cfg, system, section)

        # prefix ids so they can't collide across sections
        idmap = {n["id"]: f"s{i}-{n['id']}" for n in graph["nodes"]}
        for n in graph["nodes"]:
            n["id"] = idmap[n["id"]]
            name = n.get("properties", {}).get("name")
            if name:
                registry.setdefault(name, n["label"])
        graph["relationships"] = [
            {**r,
             "start_node_id": idmap.get(r["start_node_id"], r["start_node_id"]),
             "end_node_id": idmap.get(r["end_node_id"], r["end_node_id"])}
            for r in graph["relationships"]
            if r["start_node_id"] in idmap and r["end_node_id"] in idmap
        ]
        combined = merge_graphs(combined, graph)
        print(f"  section {i + 1}/{len(sections)}: "
              f"{len(graph['nodes'])} nodes, {len(graph['relationships'])} rels")

    # consolidation: merge intra-document duplicates, normalize rel types
    print("  consolidating...")
    consolidated = call_claude(
        client, cfg, system_prompt(cfg),
        CONSOLIDATION_PROMPT.format(data=json.dumps(combined)),
    )
    return "sectioned", consolidated


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def process_file(client, cfg: Config, path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    tokens = estimate_tokens(text)
    print(f"{path.name}: ~{tokens:,} tokens")

    strategy, graph = extract(client, cfg, text)
    return {"source_file": str(path), "strategy": strategy,
            "estimated_tokens": tokens, **graph}


def main(input_dir: str, output_file: str, cfg: Config | None = None,
         client=None) -> dict:
    cfg = cfg or Config()
    client = client or boto3.client("bedrock-runtime", region_name=cfg.region)

    md_files = sorted(Path(input_dir).glob("*.md"))
    if not md_files:
        sys.exit(f"No .md files found in {input_dir}")

    results = [process_file(client, cfg, f) for f in md_files]
    output = {
        "documents": results,
        "totals": {
            "documents": len(results),
            "nodes": sum(len(r["nodes"]) for r in results),
            "relationships": sum(len(r["relationships"]) for r in results),
        },
    }
    Path(output_file).write_text(json.dumps(output, indent=2, default=str),
                                 encoding="utf-8")
    print(f"\nDone: {output['totals']['nodes']} nodes, "
          f"{output['totals']['relationships']} relationships -> {output_file}")
    return output


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "./docs",
         sys.argv[2] if len(sys.argv) > 2 else "./extraction_output.json")